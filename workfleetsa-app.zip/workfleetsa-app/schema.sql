-- WorkFleetSA database schema

CREATE TABLE IF NOT EXISTS dealerships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL COLLATE NOCASE,   -- reserved on first signup, case-insensitive
    is_partnered INTEGER NOT NULL DEFAULT 0,
    partner_tier TEXT,                          -- 'partner_basic' (R549) or 'partner_premium' (R999)
    payment_status TEXT NOT NULL DEFAULT 'n/a',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sellers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,          -- WhatsApp number, e.g. 27821234567
    email TEXT UNIQUE,            -- account login, nullable for old/seed sellers
    password_hash TEXT,           -- nullable for old/seed sellers that never signed up
    is_dealer INTEGER NOT NULL DEFAULT 0,
    dealership_id INTEGER,        -- nullable — links dealer accounts under one dealership name
    is_blocked INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (dealership_id) REFERENCES dealerships(id)
);

CREATE TABLE IF NOT EXISTS listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id INTEGER NOT NULL,
    vehicle_type TEXT NOT NULL,        -- Bakkie / Truck / Bus / Trailer / etc.
    listing_purpose TEXT NOT NULL DEFAULT 'sale',  -- 'sale' or 'rent'
    title TEXT NOT NULL,               -- Make & model, e.g. "Toyota Hilux 2.8 GD-6"
    year INTEGER,
    mileage INTEGER,
    payload TEXT,                      -- kg, free text since trailers use capacity not payload
    transmission TEXT,
    condition TEXT,
    price INTEGER NOT NULL,            -- sale price, OR rental rate amount
    rate_period TEXT,                  -- 'day' / 'week' / 'month' — only set when renting
    deposit_amount INTEGER,            -- optional refundable deposit — only for renting
    min_rental_days INTEGER,           -- optional minimum hire period — only for renting
    description TEXT,
    province TEXT NOT NULL,
    town TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',   -- pending / active / rejected / sold
    featured INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (seller_id) REFERENCES sellers(id)
);

CREATE TABLE IF NOT EXISTS listing_photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    listing_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (listing_id) REFERENCES listings(id)
);

CREATE INDEX IF NOT EXISTS idx_listings_status ON listings(status);
CREATE INDEX IF NOT EXISTS idx_listings_type ON listings(vehicle_type);
