# WorkFleetSA — Backend

A working Flask app: public listing site + seller submission form + admin
approval queue, backed by SQLite. This replaces the earlier static mockups —
everything here is real and functional.

## What's included

- **Seller accounts** — `/signup` and `/login`, real password hashing
  (werkzeug), sessions. Listing a vehicle now requires an account — no more
  a throwaway seller record created per listing. `/my-listings` shows
  everything a logged-in seller has posted, with live status and payment
  info.
- **Public site** — homepage with live filtering (category group/type/
  province/search) plus a **For Sale / For Rent** toggle, listing detail
  pages, pricing page
- **8 category groups** — Bakkies, Panel Vans, Trucks, Buses, Trailers,
  Earthmovers, Goods Movers, and **Heavy Machinery** (generators,
  compressors, water pumps, welding machines). Heavy Machinery gets its
  own form treatment automatically: "Machine details" instead of "Vehicle
  details," "Hours Used" instead of mileage, "Uptime / Running Hours"
  instead of payload, and the Transmission field disappears entirely —
  all driven by which type the seller picks, no separate page needed.
- **Rentals** — any listing can be marked For Sale or For Rent at submission.
  Rentals capture a rate (day/week/month), an optional deposit, and an
  optional minimum hire period, and display differently everywhere
  (badges, price formatting, WhatsApp message text, safety note)
- **Seller form** (`/list-vehicle`) — choose a plan first (Basic/Featured/
  Relist), paid plans go through an EFT billing page, then a 5-step mobile
  form: Sale/Rent choice + vehicle type → details → photos → contact →
  review. Photos can be removed/replaced before submitting (× button on
  each filled slot). Saves to DB as `pending`, handles real photo uploads.
- **Pricing → Billing → List flow** — tapping "List Your Vehicle" anywhere
  on the site goes to `/list-vehicle` (choose Basic, Featured, or Relist).
  Paid plans route through `/list-vehicle/billing` showing your EFT
  details before continuing to the form. No payment gateway — it's manual
  EFT + admin verification, same as the honest limitation noted below.
- **About/Contact page** (`/about`) — founder story plus email, phone, and
  LinkedIn. Linked from the footer instead of the old Admin link.
- **Admin panel** (`/admin`) — no longer linked anywhere on the public
  site (you navigate to `/admin/login` directly). Login-protected,
  approve/reject/feature/mark-sold/delete listings, shows Sale/Rent and
  Plan/payment status (flags "⚠ verify EFT" on pending paid requests)
  at a glance. Seller names are clickable, linking to their account.
- **Dealer accounts** — signup now offers Private or Dealer. Dealer signup
  asks for a dealership name: the first person to use a name reserves it,
  anyone else signing up with the same name (case-insensitive) joins that
  same dealership automatically — so a dealership's whole team shares one
  public profile and inventory without needing a shared login.
- **Public dealership profiles** (`/dealer/<id>`) — shows the dealership
  name, a Partnered Dealer badge if they've paid for one, and every active
  listing from anyone on that dealership's team. Linked from any listing's
  detail page where the seller is a dealer.
- **Partnered Dealer badge** — dealership members see an upgrade box on
  their own profile (R549 Basic / R999 Premium), which goes through the
  same manual EFT + admin-verification pattern as listing plans. Confirm
  via `/admin/dealerships`, which also shows member counts, active listing
  counts, and flags pending EFT verification per dealership.
- **Seller-side "Mark as Sold"** — on `/my-listings`, any of your own
  active listings has a Mark as Sold button. Instantly pulls it from
  public browsing. (Ownership-checked server-side — a seller can't mark
  someone else's listing sold.) Admin can already see everything marked
  Sold under the Sold tab on `/admin` and delete it from there.
- **Admin user management** (`/admin/users`) — every registered account,
  searchable by name/email/phone, with listing counts. Click through to
  `/admin/users/<id>` for full account details and every listing they've
  ever posted. **Block/Unblock** a seller from there — blocking hides all
  of their active listings from the public site immediately and prevents
  them logging back in until unblocked.
- **Listing detail page** — rebuilt with a proper responsive layout.
  Desktop stays exactly as before (photo + description on the left,
  price/specs/contact on the right). Mobile now stacks correctly in a
  sensible order: photos → price/specs/contact → description → safety
  note, instead of the old two-column grid squishing awkwardly. Long
  descriptions (380+ characters) get a "Show more" collapse so they don't
  dominate the page on a small screen.
- **Database** — SQLite (`workfleetsa.db`), zero setup, good up to a few
  thousand listings. Migrate to Postgres later if you outgrow it.
- Pre-seeded with 12 sample listings (9 for sale, 3 for rent) on first run
  so the site isn't empty while you go source real ones.

## Run it locally (on your machine, to try it out)

```bash
cd workfleetsa-app
pip install -r requirements.txt --break-system-packages   # or use a venv
python3 app.py
```

Open **http://localhost:5000**. On first run it creates `workfleetsa.db`,
seeds 6 sample listings, and creates a default admin account.

**Admin panel:** http://localhost:5000/admin/login
Default login: `admin` / `workfleet2026`

**Change the default password immediately:**
```bash
flask --app app.py set-admin-password
```

## Deploying to your Kamatera VPS (Ubuntu 22.04)

You already run a Kamatera VPS for THM — this app is lightweight enough to
sit alongside your existing workloads.

### 1. Get the code onto the server

Upload the `workfleetsa-app` folder via `scp`, or push it to a private git
repo and `git clone` it on the VPS.

```bash
scp -r workfleetsa-app you@your-vps-ip:/home/you/
```

### 2. Install Python deps

```bash
ssh you@your-vps-ip
cd workfleetsa-app
sudo apt update && sudo apt install -y python3-pip python3-venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. Set a real secret key

```bash
export SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
```
Put this in a `.env` file or systemd environment (below) so it persists —
don't leave the app on the default dev key in production.

### 4. Initialise the database once

```bash
python3 -c "import app; app.init_db()"
flask --app app.py set-admin-password   # set a real admin password now
```

### 5. Run with gunicorn (production WSGI server, not the Flask dev server)

```bash
gunicorn --workers 3 --bind 127.0.0.1:8000 app:app
```

### 6. Keep it running with systemd

Create `/etc/systemd/system/workfleetsa.service`:

```ini
[Unit]
Description=WorkFleetSA Flask app
After=network.target

[Service]
User=you
WorkingDirectory=/home/you/workfleetsa-app
Environment="SECRET_KEY=paste-your-generated-key-here"
ExecStart=/home/you/workfleetsa-app/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:8000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable workfleetsa
sudo systemctl start workfleetsa
sudo systemctl status workfleetsa   # confirm it's running
```

### 7. Point nginx at it (reverse proxy + your domain)

Add a server block, e.g. `/etc/nginx/sites-available/workfleetsa`:

```nginx
server {
    listen 80;
    server_name workfleetsa.co.za www.workfleetsa.co.za;

    client_max_body_size 20M;   # allow photo uploads

    location /static/ {
        alias /home/you/workfleetsa-app/static/;
    }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/workfleetsa /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

Then run `certbot --nginx -d workfleetsa.co.za -d www.workfleetsa.co.za` for
free HTTPS once your domain's DNS is pointed at the VPS.

## Upgrading an existing deployment

If you already deployed an earlier version (before rentals existed), this
update is safe to drop in — `init_db()` detects the missing rental columns
on startup and adds them automatically (`ALTER TABLE`), without touching
your existing listings or wiping the database. Just replace the code and
restart the service:
```bash
sudo systemctl restart workfleetsa
```

## Backing up the database

It's a single file — back it up like any file:
```bash
cp workfleetsa.db workfleetsa-backup-$(date +%F).db
```
Worth putting on a daily cron job once you have real seller data in it.

## Known limitations (by design, for this stage)

- **No automatic payment verification** — the EFT billing page shows your
  bank details and the seller confirms manually that they've paid. There's
  no bank feed or payment gateway checking this for real, so you need to
  check your bank account and match the reference before clicking "Feature"
  in the admin panel (which flips `payment_status` to `verified`). Consider
  PayFast or Yoco later to automate this end-to-end.
- Only Basic and Featured are wired through the paid billing flow right
  now — Relist and the dealer tiers are shown on `/pricing` for information
  but don't yet have their own EFT page. Extend `PLAN_PRICES` in `app.py`
  and duplicate the billing route logic when you're ready to wire those up.
- No email/SMS notifications — sellers are told "you'll get a WhatsApp
  message once approved" but that message currently has to be sent by
  you manually. Wire up the WhatsApp Business API later to automate this
  (you've already got chatbot experience from THM Digital Services).
- Single admin login — fine for now since it's just you moderating.
- SQLite — great up to a few thousand listings; migrate to Postgres if
  you scale past that or need concurrent writes at higher volume.

## Next logical build steps

1. Wire up the WhatsApp Business API to auto-notify sellers on approval
2. Add basic image compression on upload (photos currently save as-is)
3. Add a simple payment link (PayFast/Yoco) for the Featured tier so it's
   self-serve instead of manual
4. Add search-engine-friendly URLs and meta tags per listing for SEO
