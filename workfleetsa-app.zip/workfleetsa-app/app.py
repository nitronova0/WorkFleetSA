"""
WorkFleetSA — Flask backend
Run locally:   python3 app.py
Deploy notes:  see README.md (gunicorn + nginx + systemd on your Kamatera VPS)
"""

import os
import re
import sqlite3
import uuid
from datetime import datetime

from flask import (Flask, render_template, request, redirect, url_for,
                    session, flash, g, abort)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "workfleetsa.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXT = {"jpg", "jpeg", "png", "webp"}
MAX_PHOTOS = 8

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-key-change-this-in-production")
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20MB total upload cap

PROVINCES = ["Limpopo", "Gauteng", "Western Cape", "KwaZulu-Natal",
             "Eastern Cape", "Free State", "Mpumalanga", "North West", "Northern Cape"]

# Category groups: how buyers actually think ("something that moves earth" vs
# "something that moves goods") rather than one long alphabetical list.
CATEGORY_GROUPS = {
    "Bakkies":         ["Bakkie"],
    "Panel Vans":      ["Panel Van"],
    "Trucks":          ["Truck"],
    "Buses":           ["Bus"],
    "Trailers":        ["Trailer"],
    "Earthmovers":     ["Excavator", "Dozer", "Grader", "Roller", "Loader"],
    "Goods Movers":    ["Forklift", "Crane", "Tractor", "Attachment"],
    "Heavy Machinery": ["Generator", "Compressor", "Water Pump", "Welding Machine"],
}
TYPE_TO_GROUP = {t: grp for grp, types in CATEGORY_GROUPS.items() for t in types}
VEHICLE_TYPES = [t for types in CATEGORY_GROUPS.values() for t in types]  # flat list, for the form

# Banking details shown on the billing/EFT page for paid plans (Featured listings).
# NOTE: for a real production launch, move this to an environment variable rather
# than hardcoding it, so it's not sitting in source control.
EFT_DETAILS = {
    "account_holder": "Thama Tshivhuyahuvhi",
    "account_number": "51139140094",
    "bank_name": "GoTyme Bank",
    "branch_code": "678910",
}

PLAN_PRICES = {"basic": 0, "featured": 149, "relist": 49}
PLAN_LABELS = {"basic": "Basic", "featured": "Featured Listing", "relist": "Relist"}

# Dealership-level "Partnered Dealer" badge — separate from per-listing plans above,
# since this applies to the whole dealership account, not a single vehicle.
DEALER_PARTNER_PRICES = {"partner_basic": 549, "partner_premium": 999}
DEALER_PARTNER_LABELS = {"partner_basic": "Partnered Dealer — Basic", "partner_premium": "Partnered Dealer — Premium"}

# Icon shown is per-group (7 icons), not per exact type (13 types) — keeps the
# icon set manageable while still being visually distinct by category.
GROUP_ICON_KEY = {
    "Bakkies": "bakkie", "Panel Vans": "van", "Trucks": "truck", "Buses": "bus",
    "Trailers": "trailer", "Earthmovers": "earthmover", "Goods Movers": "goodsmover",
    "Heavy Machinery": "heavymachine",
}


def type_group(vtype):
    return TYPE_TO_GROUP.get(vtype, "Trucks")


def icon_key(vtype):
    return GROUP_ICON_KEY.get(type_group(vtype), "truck")


def spec_label(vtype):
    grp = type_group(vtype)
    if grp == "Buses":
        return "SEATS"
    if grp in ("Trailers", "Earthmovers", "Goods Movers"):
        return "CAPACITY"
    return "PAYLOAD/GVM"


def rate_label(period):
    return {"day": "/ day", "week": "/ week", "month": "/ month"}.get(period, "")


app.jinja_env.globals.update(
    type_group=type_group, icon_key=icon_key, spec_label=spec_label,
    rate_label=rate_label, CATEGORY_GROUPS=CATEGORY_GROUPS, PLAN_LABELS=PLAN_LABELS,
    PLAN_PRICES=PLAN_PRICES, TYPE_TO_GROUP=TYPE_TO_GROUP,
    DEALER_PARTNER_PRICES=DEALER_PARTNER_PRICES, DEALER_PARTNER_LABELS=DEALER_PARTNER_LABELS,
)


# ---------- DB HELPERS ----------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    first_time = not os.path.exists(DB_PATH)
    db = sqlite3.connect(DB_PATH)
    with open(SCHEMA_PATH) as f:
        db.executescript(f.read())
    # admins table isn't in the original schema.sql (added here for forward-compat)
    db.execute("""CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL
    )""")
    db.commit()

    # rental fields — added after the initial schema, so patch existing DBs safely
    existing_cols = {row[1] for row in db.execute("PRAGMA table_info(listings)")}
    migrations = {
        "listing_purpose": "ALTER TABLE listings ADD COLUMN listing_purpose TEXT NOT NULL DEFAULT 'sale'",
        "rate_period": "ALTER TABLE listings ADD COLUMN rate_period TEXT",
        "deposit_amount": "ALTER TABLE listings ADD COLUMN deposit_amount INTEGER",
        "min_rental_days": "ALTER TABLE listings ADD COLUMN min_rental_days INTEGER",
        "plan_requested": "ALTER TABLE listings ADD COLUMN plan_requested TEXT NOT NULL DEFAULT 'basic'",
        "payment_status": "ALTER TABLE listings ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'n/a'",
    }
    for col, stmt in migrations.items():
        if col not in existing_cols:
            db.execute(stmt)
    db.commit()

    # seller accounts — email/password added after the initial schema
    existing_seller_cols = {row[1] for row in db.execute("PRAGMA table_info(sellers)")}
    seller_migrations = {
        "email": "ALTER TABLE sellers ADD COLUMN email TEXT",
        "password_hash": "ALTER TABLE sellers ADD COLUMN password_hash TEXT",
        "is_blocked": "ALTER TABLE sellers ADD COLUMN is_blocked INTEGER NOT NULL DEFAULT 0",
        "dealership_id": "ALTER TABLE sellers ADD COLUMN dealership_id INTEGER",
    }
    for col, stmt in seller_migrations.items():
        if col not in existing_seller_cols:
            db.execute(stmt)
    db.commit()

    # dealerships table — added after the original schema, so create it here for
    # existing installs too (CREATE TABLE IF NOT EXISTS is safe to re-run)
    db.execute("""CREATE TABLE IF NOT EXISTS dealerships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL COLLATE NOCASE,
        is_partnered INTEGER NOT NULL DEFAULT 0,
        partner_tier TEXT,
        payment_status TEXT NOT NULL DEFAULT 'n/a',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )""")
    db.commit()

    # seed default admin if none exists
    cur = db.execute("SELECT COUNT(*) FROM admins")
    if cur.fetchone()[0] == 0:
        db.execute(
            "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
            ("admin", generate_password_hash("workfleet2026")),
        )
        db.commit()
        print(">> Default admin created — username: admin / password: workfleet2026")
        print(">> CHANGE THIS before going live: flask --app app.py set-admin-password")

    # seed sample listings on first run only, so the site never launches empty
    if first_time:
        seed_sample_listings(db)
    db.close()


def seed_sample_listings(db):
    sellers = [
        ("Jaco Kruger", "27821234567", 0),
        ("Themba Ndlovu", "27835557890", 0),
        ("Limpopo Truck Traders", "27729990011", 1),
    ]
    seller_ids = []
    for name, phone, is_dealer in sellers:
        cur = db.execute(
            "INSERT INTO sellers (name, phone, is_dealer) VALUES (?, ?, ?)",
            (name, phone, is_dealer),
        )
        seller_ids.append(cur.lastrowid)

    listings = [
        # (seller, type, purpose, title, year, mileage, payload, transmission, condition,
        #  price, rate_period, deposit, min_rental_days, description, province, town, status, featured)
        (seller_ids[0], "Bakkie", "sale", "Toyota Hilux 2.8 GD-6 Legend", 2021, 68400, "1,000 kg",
         "Manual", "Good", 549900, None, None, None,
         "Full service history, one owner, canopy included.",
         "Limpopo", "Polokwane", "active", 1),
        (seller_ids[2], "Truck", "sale", "Isuzu NPR 400 Dropside", 2018, 142000, "4,100 kg",
         "Manual", "Good", 385000, None, None, None,
         "Fleet-maintained, tyres replaced 6 months ago.",
         "Limpopo", "Thohoyandou", "active", 0),
        (seller_ids[1], "Bus", "sale", "Toyota Quantum 14-Seater", 2019, 210000, "14 seats",
         "Manual", "Fair — needs some work", 320000, None, None, None,
         "Reliable runner, clutch recently done.",
         "Limpopo", "Musina", "active", 1),
        (seller_ids[0], "Bakkie", "sale", "Ford Ranger 2.2 XL D/Cab", 2020, 91200, "950 kg",
         "Manual", "Good", 412000, None, None, None,
         "Well looked after, service book available.",
         "Limpopo", "Tzaneen", "active", 0),
        (seller_ids[2], "Trailer", "sale", "Tandem Axle Flatbed Trailer", 2022, None, "3,500 kg",
         None, "Excellent", 68500, None, None, None,
         "Barely used, brakes and lights all working.",
         "Limpopo", "Giyani", "active", 0),
        (seller_ids[2], "Truck", "sale", "Mitsubishi Fuso Canter Tipper", 2017, 168000, "5,500 kg",
         "Manual", "Good", 298000, None, None, None,
         "Tipper body in solid condition, no leaks.",
         "Limpopo", "Makhado", "active", 1),
        (seller_ids[1], "Panel Van", "sale", "Toyota Quantum Panel Van 2.5D", 2019, 132000, "6.5 m³",
         "Manual", "Good", 285000, None, None, None,
         "Bulkhead fitted, ideal for courier or delivery work.",
         "Limpopo", "Polokwane", "active", 0),
        (seller_ids[2], "Excavator", "sale", "CAT 320D Excavator", 2015, None, "20 ton",
         None, "Good", 950000, None, None, None,
         "Well maintained, new tracks fitted last year.",
         "Limpopo", "Tzaneen", "active", 1),
        (seller_ids[2], "Forklift", "sale", "Toyota 2.5 Ton Diesel Forklift", 2018, None, "2,500 kg",
         "Automatic", "Good", 185000, None, None, None,
         "Warehouse-used, side shift, low hours.",
         "Limpopo", "Polokwane", "active", 0),
        (seller_ids[2], "Generator", "sale", "Cummins 100kVA Diesel Generator", 2019, None, "100 kVA",
         None, "Good", 165000, None, None, None,
         "Silent canopy, low running hours, serviced regularly.",
         "Limpopo", "Polokwane", "active", 0),
        # rentals
        (seller_ids[2], "Water Pump", "rent", "3-Inch Diesel Water Pump — For Hire", 2021, None, "3 inch",
         None, "Good", 250, "day", 2000, 1,
         "Ideal for site dewatering or irrigation, fuel not included.",
         "Limpopo", "Tzaneen", "active", 0),
        (seller_ids[2], "Trailer", "rent", "Tandem Axle Flatbed Trailer — For Hire", 2021, None, "3,500 kg",
         None, "Good", 350, "day", 1500, 1,
         "Daily and weekly rates available, delivery can be arranged locally.",
         "Limpopo", "Giyani", "active", 1),
        (seller_ids[2], "Excavator", "rent", "CAT 313 Excavator — For Hire", 2019, None, "13 ton",
         None, "Good", 2800, "day", 15000, 2,
         "Operator available on request, diesel not included.",
         "Limpopo", "Tzaneen", "active", 1),
        (seller_ids[0], "Bakkie", "rent", "Toyota Hilux D/Cab — Short-Term Hire", 2022, 41000, "1,000 kg",
         "Manual", "Excellent", 650, "day", 5000, 1,
         "Insurance included, unlimited km within Limpopo.",
         "Limpopo", "Polokwane", "active", 0),
    ]
    for l in listings:
        db.execute("""INSERT INTO listings
            (seller_id, vehicle_type, listing_purpose, title, year, mileage, payload, transmission,
             condition, price, rate_period, deposit_amount, min_rental_days,
             description, province, town, status, featured)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", l)
    db.commit()
    print(">> Seeded 14 sample listings (10 for sale, 4 for rent) across all 8 categories.")


# ---------- UTILITIES ----------

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


def phone_to_wa(raw):
    """Normalise a SA phone number to WhatsApp's international format (no +, no spaces)."""
    digits = re.sub(r"\D", "", raw or "")
    if digits.startswith("0"):
        digits = "27" + digits[1:]
    elif not digits.startswith("27"):
        digits = "27" + digits
    return digits


def row_to_dict(row):
    return dict(row) if row else None


def current_admin():
    return session.get("admin_username")


def require_admin():
    if not current_admin():
        return redirect(url_for("admin_login", next=request.path))
    return None


def current_seller():
    """Returns the logged-in seller's row, or None."""
    seller_id = session.get("seller_id")
    if not seller_id:
        return None
    db = get_db()
    row = db.execute("SELECT * FROM sellers WHERE id = ?", (seller_id,)).fetchone()
    if row and row["is_blocked"]:
        session.pop("seller_id", None)
        session.pop("seller_name", None)
        return None
    return row


def require_seller():
    if not session.get("seller_id"):
        return redirect(url_for("login", next=request.full_path))
    return None


app.jinja_env.globals["current_seller"] = current_seller


# ---------- PUBLIC ROUTES ----------

@app.route("/")
def home():
    db = get_db()
    group = request.args.get("group") or ""
    vtype = request.args.get("type") or ""
    province = request.args.get("province") or ""
    q = request.args.get("q") or ""
    purpose = request.args.get("purpose") or ""  # '', 'sale', or 'rent'

    # a specific type must belong to the selected group, otherwise ignore it
    if vtype and group and vtype not in CATEGORY_GROUPS.get(group, []):
        vtype = ""

    sql = """SELECT l.*, s.phone, s.is_dealer,
                (SELECT filename FROM listing_photos p WHERE p.listing_id = l.id
                 ORDER BY sort_order LIMIT 1) AS cover_photo
              FROM listings l JOIN sellers s ON s.id = l.seller_id
              WHERE l.status = 'active' AND s.is_blocked = 0"""
    params = []
    if purpose in ("sale", "rent"):
        sql += " AND l.listing_purpose = ?"
        params.append(purpose)
    if vtype:
        sql += " AND l.vehicle_type = ?"
        params.append(vtype)
    elif group:
        types = CATEGORY_GROUPS.get(group, [])
        sql += " AND l.vehicle_type IN (%s)" % ",".join("?" * len(types))
        params.extend(types)
    if province:
        sql += " AND l.province = ?"
        params.append(province)
    if q:
        sql += " AND l.title LIKE ?"
        params.append(f"%{q}%")
    sql += " ORDER BY l.featured DESC, l.created_at DESC"

    listings = db.execute(sql, params).fetchall()

    # counts per top-level group (respects the sale/rent toggle, for the homepage tiles)
    group_counts = {}
    for grp, types in CATEGORY_GROUPS.items():
        placeholders = ",".join("?" * len(types))
        gsql = f"SELECT COUNT(*) FROM listings WHERE status='active' AND vehicle_type IN ({placeholders})"
        gparams = list(types)
        if purpose in ("sale", "rent"):
            gsql += " AND listing_purpose = ?"
            gparams.append(purpose)
        group_counts[grp] = db.execute(gsql, gparams).fetchone()[0]

    # counts per specific type within the selected group (for the sub-filter chips)
    type_counts = {}
    if group:
        for t in CATEGORY_GROUPS.get(group, []):
            tsql = "SELECT COUNT(*) FROM listings WHERE status='active' AND vehicle_type=?"
            tparams = [t]
            if purpose in ("sale", "rent"):
                tsql += " AND listing_purpose = ?"
                tparams.append(purpose)
            type_counts[t] = db.execute(tsql, tparams).fetchone()[0]

    total_active = db.execute("SELECT COUNT(*) FROM listings WHERE status='active'").fetchone()[0]
    rent_count = db.execute(
        "SELECT COUNT(*) FROM listings WHERE status='active' AND listing_purpose='rent'"
    ).fetchone()[0]
    sale_count = total_active - rent_count

    return render_template(
        "index.html", active="home", listings=listings, group_counts=group_counts,
        type_counts=type_counts, total_active=total_active, provinces=PROVINCES,
        current_group=group, current_type=vtype, current_province=province, query=q,
        current_purpose=purpose, sale_count=sale_count, rent_count=rent_count,
    )


@app.route("/listing/<int:listing_id>")
def listing_detail(listing_id):
    db = get_db()
    listing = db.execute(
        """SELECT l.*, s.phone, s.is_dealer, s.is_blocked, s.dealership_id, d.name AS dealership_name
           FROM listings l
           JOIN sellers s ON s.id = l.seller_id
           LEFT JOIN dealerships d ON d.id = s.dealership_id
           WHERE l.id = ?""",
        (listing_id,),
    ).fetchone()
    if not listing or listing["status"] != "active" or listing["is_blocked"]:
        abort(404)
    photos = db.execute(
        "SELECT * FROM listing_photos WHERE listing_id = ? ORDER BY sort_order", (listing_id,)
    ).fetchall()
    return render_template("listing_detail.html", active="home", listing=listing, photos=photos)


@app.route("/pricing")
def pricing():
    return render_template("pricing.html", active="pricing")


@app.route("/about")
def about():
    return render_template("about.html", active="about")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if current_seller():
        return redirect(request.args.get("next") or url_for("list_vehicle"))

    if request.method == "GET":
        return render_template("signup.html", active="account", next=request.args.get("next", ""))

    db = get_db()
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    phone = request.form.get("phone", "").strip()
    password = request.form.get("password", "")
    account_type = request.form.get("account_type", "private")
    dealership_name = request.form.get("dealership_name", "").strip()
    next_url = request.form.get("next") or url_for("list_vehicle")

    if not name or not email or not phone or not password:
        flash("Please fill in every field to create your account.", "error")
        return render_template("signup.html", active="account", next=next_url), 400
    if len(password) < 6:
        flash("Your password needs to be at least 6 characters.", "error")
        return render_template("signup.html", active="account", next=next_url), 400
    if account_type == "dealer" and not dealership_name:
        flash("Please enter your dealership name.", "error")
        return render_template("signup.html", active="account", next=next_url), 400

    existing = db.execute("SELECT id FROM sellers WHERE email = ?", (email,)).fetchone()
    if existing:
        flash("An account with that email already exists — try logging in instead.", "error")
        return render_template("signup.html", active="account", next=next_url), 400

    is_dealer = 1 if account_type == "dealer" else 0
    dealership_id = None
    if is_dealer:
        # Case-insensitive match — if the dealership name is already registered,
        # this new account joins it (so co-workers share one dealership).
        # Otherwise this signup reserves the name for that dealership.
        existing_dealership = db.execute(
            "SELECT id FROM dealerships WHERE name = ? COLLATE NOCASE", (dealership_name,)
        ).fetchone()
        if existing_dealership:
            dealership_id = existing_dealership["id"]
        else:
            cur = db.execute("INSERT INTO dealerships (name) VALUES (?)", (dealership_name,))
            dealership_id = cur.lastrowid

    cur = db.execute(
        "INSERT INTO sellers (name, phone, email, password_hash, is_dealer, dealership_id) VALUES (?,?,?,?,?,?)",
        (name, phone_to_wa(phone), email, generate_password_hash(password), is_dealer, dealership_id),
    )
    db.commit()
    session["seller_id"] = cur.lastrowid
    session["seller_name"] = name
    flash(f"Welcome, {name}! Your account is ready.", "success")
    return redirect(next_url)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_seller():
        return redirect(request.args.get("next") or url_for("list_vehicle"))

    if request.method == "GET":
        return render_template("login.html", active="account", next=request.args.get("next", ""))

    db = get_db()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    next_url = request.form.get("next") or url_for("list_vehicle")

    row = db.execute("SELECT * FROM sellers WHERE email = ?", (email,)).fetchone()
    if not row or not row["password_hash"] or not check_password_hash(row["password_hash"], password):
        flash("Incorrect email or password.", "error")
        return render_template("login.html", active="account", next=next_url), 401

    if row["is_blocked"]:
        flash("This account has been suspended. Contact workfleetsa@gmail.com if you think this is a mistake.", "error")
        return render_template("login.html", active="account", next=next_url), 403

    session["seller_id"] = row["id"]
    session["seller_name"] = row["name"]
    flash(f"Welcome back, {row['name']}!", "success")
    return redirect(next_url)


@app.route("/logout")
def logout():
    session.pop("seller_id", None)
    session.pop("seller_name", None)
    return redirect(url_for("home"))


@app.route("/my-listings")
def my_listings():
    redir = require_seller()
    if redir:
        return redir
    db = get_db()
    seller_id = session["seller_id"]
    listings = db.execute(
        "SELECT * FROM listings WHERE seller_id = ? ORDER BY created_at DESC", (seller_id,)
    ).fetchall()
    return render_template("my_listings.html", active="account", listings=listings)


@app.route("/my-listings/<int:listing_id>/sold", methods=["POST"])
def my_listing_mark_sold(listing_id):
    redir = require_seller()
    if redir:
        return redir
    db = get_db()
    seller_id = session["seller_id"]
    listing = db.execute(
        "SELECT * FROM listings WHERE id = ? AND seller_id = ?", (listing_id, seller_id)
    ).fetchone()
    if not listing:
        abort(404)
    db.execute("UPDATE listings SET status='sold' WHERE id=?", (listing_id,))
    db.commit()
    flash("Marked as sold. Thanks for keeping the listings fresh!", "success")
    return redirect(url_for("my_listings"))


@app.route("/dealer/<int:dealership_id>")
def dealer_profile(dealership_id):
    db = get_db()
    dealership = db.execute("SELECT * FROM dealerships WHERE id = ?", (dealership_id,)).fetchone()
    if not dealership:
        abort(404)
    listings = db.execute(
        """SELECT l.*, s.phone,
             (SELECT filename FROM listing_photos p WHERE p.listing_id = l.id
              ORDER BY sort_order LIMIT 1) AS cover_photo
           FROM listings l JOIN sellers s ON s.id = l.seller_id
           WHERE s.dealership_id = ? AND l.status = 'active' AND s.is_blocked = 0
           ORDER BY l.featured DESC, l.created_at DESC""",
        (dealership_id,),
    ).fetchall()
    seller = current_seller()
    can_manage = bool(seller and seller["dealership_id"] == dealership_id)
    return render_template(
        "dealer_profile.html", active="dealer", dealership=dealership,
        listings=listings, can_manage=can_manage,
    )


@app.route("/dealer/<int:dealership_id>/partner-billing")
def dealer_partner_billing(dealership_id):
    redir = require_seller()
    if redir:
        return redir
    seller = current_seller()
    if not seller or seller["dealership_id"] != dealership_id:
        abort(403)
    db = get_db()
    dealership = db.execute("SELECT * FROM dealerships WHERE id = ?", (dealership_id,)).fetchone()
    if not dealership:
        abort(404)
    tier = request.args.get("tier", "partner_basic")
    if tier not in DEALER_PARTNER_PRICES:
        tier = "partner_basic"
    return render_template(
        "dealer_partner_billing.html", dealership=dealership, tier=tier,
        price=DEALER_PARTNER_PRICES[tier], eft=EFT_DETAILS,
    )


@app.route("/dealer/<int:dealership_id>/partner-confirm", methods=["POST"])
def dealer_partner_confirm(dealership_id):
    redir = require_seller()
    if redir:
        return redir
    seller = current_seller()
    if not seller or seller["dealership_id"] != dealership_id:
        abort(403)
    db = get_db()
    tier = request.form.get("tier", "partner_basic")
    if tier not in DEALER_PARTNER_PRICES:
        tier = "partner_basic"
    db.execute(
        "UPDATE dealerships SET partner_tier=?, payment_status='pending_verification' WHERE id=?",
        (tier, dealership_id),
    )
    db.commit()
    flash("Thanks! We'll confirm your EFT and activate your Partnered Dealer badge — usually within a few hours.", "success")
    return redirect(url_for("dealer_profile", dealership_id=dealership_id))


@app.route("/list-vehicle")
def list_vehicle():
    """Landing step: choose Basic (free) or Featured (paid) before starting the form."""
    return render_template("list_plan.html", active="list")


@app.route("/list-vehicle/billing")
def list_vehicle_billing():
    redir = require_seller()
    if redir:
        return redir
    plan = request.args.get("plan", "featured")
    if plan not in PLAN_PRICES or plan == "basic":
        return redirect(url_for("list_vehicle_create", plan="basic"))
    return render_template(
        "list_billing.html", active="list", plan=plan, plan_label=PLAN_LABELS[plan],
        price=PLAN_PRICES[plan], eft=EFT_DETAILS,
    )


@app.route("/list-vehicle/create", methods=["GET", "POST"])
def list_vehicle_create():
    redir = require_seller()
    if redir:
        return redir
    seller = current_seller()

    plan = request.args.get("plan") or request.form.get("plan_requested") or "basic"
    if plan not in PLAN_PRICES:
        plan = "basic"

    if request.method == "GET":
        return render_template(
            "list_vehicle.html", active="list", provinces=PROVINCES, plan=plan, seller=seller,
        )

    db = get_db()
    form = request.form
    plan = form.get("plan_requested") if form.get("plan_requested") in PLAN_PRICES else plan

    purpose = form.get("listing_purpose") if form.get("listing_purpose") in ("sale", "rent") else "sale"

    required = ["vehicle_type", "title", "year", "mileage", "condition", "price", "province", "town"]
    if purpose == "rent":
        required.append("rate_period")
    missing = [f for f in required if not form.get(f)]
    if missing:
        flash("Please fill in all required fields before submitting.", "error")
        return render_template(
            "list_vehicle.html", active="list", provinces=PROVINCES, plan=plan, seller=seller,
        ), 400

    payment_status = "pending_verification" if PLAN_PRICES.get(plan, 0) > 0 else "n/a"
    seller_id = seller["id"]

    cur = db.execute(
        """INSERT INTO listings
           (seller_id, vehicle_type, listing_purpose, title, year, mileage, payload, transmission,
            condition, price, rate_period, deposit_amount, min_rental_days,
            description, province, town, status, plan_requested, payment_status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'pending', ?, ?)""",
        (seller_id, form.get("vehicle_type"), purpose, form.get("title"),
         form.get("year") or None, form.get("mileage") or None, form.get("payload") or None,
         form.get("transmission"), form.get("condition"), form.get("price"),
         form.get("rate_period") if purpose == "rent" else None,
         form.get("deposit_amount") or None if purpose == "rent" else None,
         form.get("min_rental_days") or None if purpose == "rent" else None,
         form.get("description"), form.get("province"), form.get("town"),
         plan, payment_status),
    )
    listing_id = cur.lastrowid

    files = request.files.getlist("photos")
    order = 0
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    for file in files[:MAX_PHOTOS]:
        if file and file.filename and allowed_file(file.filename):
            ext = file.filename.rsplit(".", 1)[1].lower()
            fname = f"{uuid.uuid4().hex}.{ext}"
            file.save(os.path.join(UPLOAD_DIR, fname))
            db.execute(
                "INSERT INTO listing_photos (listing_id, filename, sort_order) VALUES (?,?,?)",
                (listing_id, fname, order),
            )
            order += 1

    db.commit()
    return render_template(
        "list_success.html", active="list", vehicle_type=form.get("vehicle_type"), plan=plan,
    )


# ---------- ADMIN ROUTES ----------

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "GET":
        return render_template("admin_login.html")
    db = get_db()
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    row = db.execute("SELECT * FROM admins WHERE username = ?", (username,)).fetchone()
    if row and check_password_hash(row["password_hash"], password):
        session["admin_username"] = username
        flash("Logged in.", "success")
        return redirect(request.args.get("next") or url_for("admin_dashboard"))
    flash("Incorrect username or password.", "error")
    return render_template("admin_login.html"), 401


@app.route("/admin/logout")
def admin_logout():
    session.pop("admin_username", None)
    return redirect(url_for("admin_login"))


@app.route("/admin")
def admin_dashboard():
    redir = require_admin()
    if redir:
        return redir
    db = get_db()
    status_filter = request.args.get("status", "pending")
    if status_filter == "all":
        rows = db.execute(
            """SELECT l.*, s.name AS seller_name, s.phone FROM listings l
               JOIN sellers s ON s.id = l.seller_id ORDER BY l.created_at DESC"""
        ).fetchall()
    else:
        rows = db.execute(
            """SELECT l.*, s.name AS seller_name, s.phone FROM listings l
               JOIN sellers s ON s.id = l.seller_id
               WHERE l.status = ? ORDER BY l.created_at DESC""",
            (status_filter,),
        ).fetchall()
    counts = {
        s: db.execute("SELECT COUNT(*) FROM listings WHERE status=?", (s,)).fetchone()[0]
        for s in ["pending", "active", "rejected", "sold"]
    }
    return render_template(
        "admin_dashboard.html", listings=rows, status_filter=status_filter,
        counts=counts, admin_username=current_admin(),
    )


@app.route("/admin/dealerships")
def admin_dealerships():
    redir = require_admin()
    if redir:
        return redir
    db = get_db()
    dealerships = db.execute(
        """SELECT d.*,
             (SELECT COUNT(*) FROM sellers WHERE dealership_id = d.id) AS member_count,
             (SELECT COUNT(*) FROM listings l JOIN sellers s ON s.id = l.seller_id
              WHERE s.dealership_id = d.id AND l.status = 'active') AS active_listings
           FROM dealerships d ORDER BY d.created_at DESC"""
    ).fetchall()
    return render_template("admin_dealerships.html", dealerships=dealerships, admin_username=current_admin())


@app.route("/admin/dealerships/<int:dealership_id>/<action>", methods=["POST"])
def admin_dealership_action(dealership_id, action):
    redir = require_admin()
    if redir:
        return redir
    db = get_db()
    if action == "confirm_partner":
        db.execute(
            "UPDATE dealerships SET is_partnered=1, payment_status='verified' WHERE id=?", (dealership_id,)
        )
        flash("Dealership confirmed as Partnered.", "success")
    elif action == "remove_partner":
        db.execute(
            "UPDATE dealerships SET is_partnered=0, payment_status='n/a' WHERE id=?", (dealership_id,)
        )
        flash("Partnered status removed.", "success")
    else:
        abort(400)
    db.commit()
    return redirect(url_for("admin_dealerships"))


@app.route("/admin/users")
def admin_users():
    redir = require_admin()
    if redir:
        return redir
    db = get_db()
    q = request.args.get("q") or ""
    sql = """SELECT s.*,
                (SELECT COUNT(*) FROM listings WHERE seller_id = s.id) AS listing_count
              FROM sellers s WHERE s.email IS NOT NULL"""
    params = []
    if q:
        sql += " AND (s.name LIKE ? OR s.email LIKE ? OR s.phone LIKE ?)"
        params.extend([f"%{q}%", f"%{q}%", f"%{q}%"])
    sql += " ORDER BY s.created_at DESC"
    users = db.execute(sql, params).fetchall()
    return render_template("admin_users.html", users=users, query=q, admin_username=current_admin())


@app.route("/admin/users/<int:seller_id>")
def admin_user_detail(seller_id):
    redir = require_admin()
    if redir:
        return redir
    db = get_db()
    seller = db.execute("SELECT * FROM sellers WHERE id = ?", (seller_id,)).fetchone()
    if not seller:
        abort(404)
    listings = db.execute(
        "SELECT * FROM listings WHERE seller_id = ? ORDER BY created_at DESC", (seller_id,)
    ).fetchall()
    return render_template(
        "admin_user_detail.html", seller=seller, listings=listings, admin_username=current_admin(),
    )


@app.route("/admin/users/<int:seller_id>/<action>", methods=["POST"])
def admin_user_action(seller_id, action):
    redir = require_admin()
    if redir:
        return redir
    db = get_db()
    if action == "block":
        db.execute("UPDATE sellers SET is_blocked=1 WHERE id=?", (seller_id,))
        flash("Account blocked. Their listings are now hidden from the public site.", "success")
    elif action == "unblock":
        db.execute("UPDATE sellers SET is_blocked=0 WHERE id=?", (seller_id,))
        flash("Account unblocked.", "success")
    else:
        abort(400)
    db.commit()
    return redirect(url_for("admin_user_detail", seller_id=seller_id))


@app.route("/admin/listing/<int:listing_id>/<action>", methods=["POST"])
def admin_listing_action(listing_id, action):
    redir = require_admin()
    if redir:
        return redir
    db = get_db()
    if action == "approve":
        db.execute("UPDATE listings SET status='active' WHERE id=?", (listing_id,))
        flash("Listing approved and now live.", "success")
    elif action == "reject":
        db.execute("UPDATE listings SET status='rejected' WHERE id=?", (listing_id,))
        flash("Listing rejected.", "success")
    elif action == "sold":
        db.execute("UPDATE listings SET status='sold' WHERE id=?", (listing_id,))
        flash("Listing marked as sold.", "success")
    elif action == "feature":
        db.execute(
            "UPDATE listings SET featured=1, payment_status='verified' WHERE id=?", (listing_id,)
        )
        flash("Listing featured.", "success")
    elif action == "unfeature":
        db.execute("UPDATE listings SET featured=0 WHERE id=?", (listing_id,))
        flash("Listing unfeatured.", "success")
    elif action == "delete":
        db.execute("DELETE FROM listing_photos WHERE listing_id=?", (listing_id,))
        db.execute("DELETE FROM listings WHERE id=?", (listing_id,))
        flash("Listing deleted.", "success")
    else:
        abort(400)
    db.commit()
    return redirect(url_for("admin_dashboard", status=request.args.get("status", "pending")))


# ---------- CLI ----------

@app.cli.command("set-admin-password")
def set_admin_password():
    """Usage: flask --app app.py set-admin-password"""
    import getpass
    username = input("Admin username [admin]: ").strip() or "admin"
    password = getpass.getpass("New password: ")
    db = sqlite3.connect(DB_PATH)
    db.execute("DELETE FROM admins WHERE username = ?", (username,))
    db.execute(
        "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
        (username, generate_password_hash(password)),
    )
    db.commit()
    db.close()
    print(f"Password updated for '{username}'.")


if __name__ == "__main__":
    init_db()
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    app.run(host="0.0.0.0", port=5000, debug=True)
else:
    # also init when run under gunicorn
    init_db()
    os.makedirs(UPLOAD_DIR, exist_ok=True)
